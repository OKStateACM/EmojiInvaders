﻿using UnityEngine;
using System.Collections;

public class MainController : MonoBehaviour {

	private static float ballSpeed = 5.0f;
	private static float radius = 0.5f;
	private static int numEmojis = 4;

	public GameObject emoji1Prefab;
	public GameObject emoji2Prefab;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		float left = GameObject.Find ("left").transform.position.x;
		float right = GameObject.Find ("right").transform.position.x;
		float front = GameObject.Find ("front").transform.position.z;
		float back = GameObject.Find ("back").transform.position.z;

		// Checks input and moves the ball
		if (Input.GetKey (KeyCode.LeftArrow)) {
			float dx = ballSpeed * Time.deltaTime;
			if (transform.position.x < left - radius + dx) {
				transform.Translate (dx, 0, 0);
			}
		}
		if (Input.GetKey (KeyCode.RightArrow)) {
			float dx = ballSpeed * Time.deltaTime;
			if (transform.position.x > right + radius - dx) {
				transform.Translate (-dx, 0, 0);
			}
		}
		if (Input.GetKey (KeyCode.UpArrow)) {
			float dz = ballSpeed * Time.deltaTime;
			if (transform.position.z > back + radius - dz) {
				transform.Translate (0, 0, -dz);
			}
		}
		if (Input.GetKey (KeyCode.DownArrow)) {
			float dz = ballSpeed * Time.deltaTime;
			if (transform.position.z < front - radius + dz) {
				transform.Translate (0, 0, dz);
			}
		}

		// Spawn new emojis as needed
		if (GameObject.Find ("emoji1Prefab(Clone)") == null &&
		    GameObject.Find ("emoji2Prefab(Clone)") == null) {
			for (int i = 0; i < numEmojis; i++) {
				GameObject go = null;
				if (i < numEmojis / 2) {
					go = (GameObject)Instantiate (emoji1Prefab);
				} else {
					go = (GameObject)Instantiate (emoji2Prefab);
				}

				float x = Random.Range (right, left);
				float y = go.transform.position.y;
				float z = Random.Range (back, front);
				go.transform.position = new Vector3 (x, y, z);
			}
		}

	}
}
