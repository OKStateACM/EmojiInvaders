﻿using UnityEngine;
using System.Collections;

public class EmojiScript : MonoBehaviour {

	private float radius = 0.7f;
	private int state = 0;
	private float scale = 0.1f;

	// Use this for initialization
	void Start () {
		scale = Random.Range (0.001f, 0.1f);
		transform.localScale = new Vector3 (scale, scale, scale);
	}
	
	// Update is called once per frame
	void Update () {

		if (state == 0) {
			scale = scale * 1.05f;
			if (scale > 1.3f)
				state = 1;
		}
		if (state == 1) {
			scale = scale * 0.95f;
			if (scale < 1.0f)
				state = 2;
		}
		transform.localScale = new Vector3 (scale, scale, scale);



		Vector3 bp = GameObject.Find ("player").transform.position;
		float distance = Vector3.Distance (bp, transform.position);
		if (distance < radius) {
			Destroy (gameObject);
		}
	}
}
